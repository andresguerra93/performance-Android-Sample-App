// app/build.gradle.kts

// Aplicación de plugins usando la sintaxis de Kotlin DSL
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // Si gestionas versiones de plugins en TOML, sería algo como:
    // alias(libs.plugins.android.application)
    // alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.examplebadapplicationoverdraw" // Cambia si es necesario
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.examplebadapplicationoverdraw"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        getByName("debug") {
            // LeakCanary se activa automáticamente en debug
            // La dependencia se añade más abajo.
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // Referencias a las librerías definidas en libs.versions.toml
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.google.material)
    implementation(libs.androidx.constraintlayout)

    // LeakCanary (SOLO para debug) usando catálogo de versiones
    debugImplementation(libs.leakcanary.android)

    // Dependencias de Test
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // Descomenta si la necesitas para la app "buena"
    // implementation(libs.androidx.lifecycle.runtime.ktx)
}
