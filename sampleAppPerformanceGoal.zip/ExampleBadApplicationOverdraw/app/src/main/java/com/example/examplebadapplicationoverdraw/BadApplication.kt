package com.example.examplebadapplicationoverdraw

import android.app.Application
import android.content.Context

class BadApplication : Application() {

    companion object {
        // LEAK 1: Referencia estática al Context de la Activity (¡MUY MAL!)
        // Esto se inicializará en BadMainActivity
        var leakyContext: Context? = null
    }

    override fun onCreate() {
        super.onCreate()
        // LeakCanary se inicializa automáticamente en debug builds.
        // No necesitamos código aquí para LeakCanary v2+.

        // Inicializamos el Singleton problemático aquí (aunque no es necesario para el leak del singleton)
        // El problema real es cuando se le pasa un Context de Activity
        // SingletonHelper.initialize(this) // Inicializar con ApplicationContext sería lo correcto
    }
}