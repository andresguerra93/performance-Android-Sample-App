package com.example.examplebadapplicationoverdraw


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import com.example.examplebadapplicationoverdraw.databinding.ActivityBadMainBinding // Importa el ViewBinding generado

class BadMainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBadMainBinding
    private val handler = Handler(Looper.getMainLooper()) // Handler para leak

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBadMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // LEAK 1 (Continuación): Guardamos el Context de esta Activity en la variable estática
        BadApplication.leakyContext = this
        Log.d("BadMainActivity", "Leaky context set in Application companion object")

        binding.buttonStartTask.setOnClickListener {
            startLeakyTask()
            // startLeakyHandlerTask() // Descomenta para probar el leak del Handler
        }

        binding.buttonOpenDetail.setOnClickListener {
            // LEAK 3: Iniciamos una Activity que usará el Singleton problemático
            val intent = Intent(this, LeakDetailActivity::class.java)
            startActivity(intent)
        }

        Log.d("BadMainActivity", "onCreate completed")
    }

    // LEAK 2: Tarea en segundo plano usando una clase interna NO estática (Thread)
    private fun startLeakyTask() {
        binding.textViewStatus.text = getString(R.string.status_running_thread)
        LeakyBackgroundTask().start() // Inicia la tarea que referencia implícitamente a BadMainActivity
    }

    // Clase interna NO estática - ¡Mantiene referencia a BadMainActivity!
    inner class LeakyBackgroundTask : Thread() {
        override fun run() {
            Log.d("BadMainActivity", "LeakyBackgroundTask started...")
            try {
                // Simula trabajo largo (15 segundos)
                SystemClock.sleep(15000)

                // Intenta actualizar UI (¡Peligroso desde hilo secundario!)
                // La referencia implícita a 'this@BadMainActivity' causa el leak si la activity se destruye.
                runOnUiThread {
                    // Comprobar si la activity todavía existe sería más seguro,
                    // pero el leak ocurre por mantener la referencia, no por esta llamada.
                    if (!isDestroyed && !isFinishing) {
                        binding.textViewStatus.text = getString(R.string.status_thread_finished)
                        Toast.makeText(this@BadMainActivity, "Thread task finished!", Toast.LENGTH_SHORT).show()
                        Log.d("BadMainActivity", "LeakyBackgroundTask finished and updated UI.")
                    } else {
                        Log.d("BadMainActivity", "LeakyBackgroundTask finished but Activity was destroyed.")
                    }
                }
            } catch (e: InterruptedException) {
                Log.w("BadMainActivity", "LeakyBackgroundTask interrupted.")
                Thread.currentThread().interrupt()
            }
        }
    }


    // LEAK 4: Tarea retrasada con Handler usando Runnable anónimo
    private fun startLeakyHandlerTask() {
        binding.textViewStatus.text = getString(R.string.status_running_handler)
        Log.d("BadMainActivity", "Posting delayed leaky runnable...")
        handler.postDelayed(object : Runnable { // Runnable anónimo (clase interna no estática)
            override fun run() {
                // Este código se ejecutará después de 20 segundos.
                // Si BadMainActivity se destruye antes, este Runnable la mantendrá viva (leak).
                if (!isDestroyed && !isFinishing) {
                    binding.textViewStatus.text = getString(R.string.status_handler_finished)
                    Toast.makeText(this@BadMainActivity, "Handler task finished!", Toast.LENGTH_SHORT).show()
                    Log.d("BadMainActivity", "Leaky Handler Runnable executed.")
                } else {
                    Log.d("BadMainActivity", "Leaky Handler Runnable executed but Activity was destroyed.")
                }
            }
        }, 20000) // 20 segundos de retraso
    }


    override fun onDestroy() {
        super.onDestroy()
        Log.d("BadMainActivity", "onDestroy called.")
        // OLVIDO 1: No limpiamos la referencia estática (aunque el daño principal ya está hecho al asignarla)
        // BadApplication.leakyContext = null // Hacer esto aquí no soluciona el leak si algo más la referencia

        // OLVIDO 2: No cancelamos/interrumpimos el LeakyBackgroundTask si sigue corriendo.

        // OLVIDO 3: No removemos los callbacks pendientes del Handler
        // handler.removeCallbacksAndMessages(null) // <-- ¡Esto faltaría para prevenir el leak del Handler!

        Log.d("BadMainActivity", "onDestroy finished.")
        // Al salir de esta Activity (rotar pantalla, presionar atrás), LeakCanary debería detectar:
        // 1. El leak causado por BadApplication.leakyContext (si algo más lo usa).
        // 2. El leak causado por LeakyBackgroundTask si aún no ha terminado.
        // 3. El leak causado por el Runnable del Handler si aún no se ha ejecutado.
    }
}