package com.example.examplebadapplicationoverdraw

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.util.Log

class LeakDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Usaremos un layout simple programáticamente para no añadir otro XML
        setContentView(createSimpleLayout())

        Log.d("LeakDetailActivity", "onCreate called.")

        // LEAK 3 (Continuación): Inicializamos/Re-inicializamos el Singleton
        // pasándole el Context de ESTA Activity. ¡Esto causará un leak!
        SingletonHelper.initialize(this)

        // Hacemos algo con el singleton para demostrar que usa nuestro context
        SingletonHelper.doSomethingThatNeedsContext()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("LeakDetailActivity", "onDestroy called.")
        // OLVIDO 4: No limpiamos el context del Singleton aquí.
        // Aunque llamáramos a SingletonHelper.clearContext(), si el Singleton
        // sigue vivo, el daño ya está hecho al haber guardado la referencia.
        // La solución real es NUNCA pasarle el Context de la Activity.

        // Al salir de esta Activity, LeakCanary debería detectar que
        // LeakDetailActivity está filtrada a través de SingletonHelper.context
    }

    private fun createSimpleLayout(): android.view.View {
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(30, 30, 30, 30)
            gravity = android.view.Gravity.CENTER
        }
        val textView = TextView(this).apply {
            text = getString(R.string.detail_activity_info)
            textSize = 18f
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        val button = Button(this).apply {
            text = "Usar Singleton"
            setOnClickListener {
                SingletonHelper.doSomethingThatNeedsContext()
            }
        }
        layout.addView(textView)
        layout.addView(button)
        return layout
    }
}
