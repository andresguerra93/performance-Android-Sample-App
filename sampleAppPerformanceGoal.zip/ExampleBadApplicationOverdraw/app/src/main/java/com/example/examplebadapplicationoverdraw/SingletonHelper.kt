package com.example.examplebadapplicationoverdraw

import android.content.Context
import android.util.Log
import android.widget.Toast
import java.lang.ref.WeakReference

// LEAK 3: Singleton que guarda una referencia directa al Context (¡MAL!)
object SingletonHelper {

    private var context: Context? = null // Referencia directa al Context
    // private var contextRef: WeakReference<Context>? = null // Forma correcta sería con WeakReference o ApplicationContext

    // Método para inicializar (o re-inicializar) con CUALQUIER context
    fun initialize(ctx: Context) {
        Log.d("SingletonHelper", "Initializing Singleton with context: ${ctx.javaClass.simpleName}")
        this.context = ctx // Guarda la referencia directa - ¡PELIGRO SI ES CONTEXT DE ACTIVITY!

        // Mostramos un Toast para ver qué context se usó
        Toast.makeText(
            ctx.applicationContext, // Usamos app context para el Toast por seguridad
            String.format(ctx.getString(R.string.singleton_init_toast), ctx.javaClass.simpleName),
            Toast.LENGTH_LONG
        ).show()
    }

    // Método que usa el context guardado
    fun doSomethingThatNeedsContext() {
        if (context == null) {
            Log.e("SingletonHelper", "Context is null! Cannot do something.")
            return
        }

        // Accedemos a recursos usando el context guardado (que podría ser de una Activity destruida)
        try {
            val appName = context?.getString(R.string.app_name)
            Log.d("SingletonHelper", "Doing something using context. App name: $appName")
            // En una app real, esto podría ser acceso a SharedPreferences, base de datos, etc.
            Toast.makeText(context, "Singleton doing something with ${context?.javaClass?.simpleName}", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Log.e("SingletonHelper", "Error using leaked context?", e)
            // Podría crashear aquí si el context es inválido
        }
    }

    // Método para simular limpieza (pero no soluciona el leak si la referencia persiste)
    fun clearContext() {
        Log.d("SingletonHelper", "Clearing context reference.")
        this.context = null
    }
}
